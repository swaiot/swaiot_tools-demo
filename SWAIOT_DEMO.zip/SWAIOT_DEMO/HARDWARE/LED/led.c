/**
* Copyright(C),Skyworth Group Co.,Ltd  
* Author: xumeilin@skyworth.com
* Review and doc: dengxuechao@skyworth.com dengxuechao509@qq.com
* Version:  0.2.1
* MIT Licensed
*
* MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
* MMMMM:.........MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM....MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
* MMMN...........MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM ...MMMMMMMMMMMMMMMMMMMMMMMMM . MMMMM
* MMM.... MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM ...MMMMM
* MMM ...MMMMMMMMMM  ..MMMMMMM....:MMMMMMM ..$MMM,........,MMMMMM ...MMMMMMMM ......MMMMMM .........MM
* MMM. .  OMMMMMMMMM . +MMMMMM.....MMMMMM ...MMM .. , ......NMMMM ...MMMMM  ..........NMMM..........MM
* MMMMM ....NMMMMMMM....MMMMM .....MMMMM ...MMMMMMMMMMMMD....MMMM ...MMMM....~MMMMM ...=MMMM,...MMMMMM
* MMMMMM=....,MMMMMMM ..IMMMD .. ...MMMM ..MMMMMMMMMMMMM ....MMMM ...MMM ...MMMMMMMM ...MMMM ...MMMMMM
* MMMMMMMM  ... MMMMM....MMM...MM ..MMM .. MMMMMMM ......... MMMD....MMM ...MMMMMMMM ...MMMM....MMMMMM
* MMMMMMMMMM  .. MMMMM...?M,.. MM....M=...MMMMM ... .?MM8...8MMM~...?MMM....MMMMMMMM ...MMMM....MMMMMM
* MMMMMMMMMMM. ..MMMMM~...M ..MMMM ..M...MMMMM ...MMMMMM:...MMMM ...?MMM....MMMMMMMM ...MMMM ...MMMMMM
* MM :MNMMMM.....MMMMMM .....OMMMM......?MMMMM....MMMMMM....MMMM....?MMMM....MMMMM, ...MMMMM ...8MMMMM
* MM . .........MMMMMMMM,....MMMMM:.... MMMMMM  ......,M....MMMM ...MMMMMM  ......... MMMMMM  ......MM
* MMMI.. . . ZMMMMMMMMMM ...MMMMMMM ...MMMMMMMMN  ....MM....MMMM....MMMMMMMM7. ... MMMMMMMMMM$. .  ,MM
* MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
**/
#include "LED.h"
#include "iot_user_config.h"

/*************************************************************************** 
Function....: initSysTick
Description.: Initial systick ,main clock is 72M, SysTick->LOAD = 9 is 1us
Parameters..: NONE 
Return......: NONE  
****************************************************************************/

void initSysTick(void)
{
    SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK_Div8); // choose clock
    SysTick->CTRL |= SysTick_CTRL_TICKINT_Msk;            // enable interrupt 
    SysTick->CTRL |= SysTick_CTRL_ENABLE_Msk;             // enable timer
    SysTick->LOAD = 9000;                                    // 1ms
}

/*************************************************************************** 
Function....: initLED
Description.: Config GPIO,use PB5  
Parameters..: NONE 
Return......: NONE  
****************************************************************************/

void initLED(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;  

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE); // enable GPIOB

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;  		      // choose PB5 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;    // set output
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;   // speed 50MHz
	GPIO_Init(GPIOB, &GPIO_InitStructure);			          
	GPIO_ResetBits(GPIOB, GPIO_Pin_5);				          // low:led on  high:led off
}

/*************************************************************************** 
Function....: checkLedStatus
Description.: Upload the staus of led  
Parameters..: NONE 
Return......: NONE  
****************************************************************************/

void checkLedStatus(void)
{
	if(keyFlag == 1){
		 keyFlag = 0;
		 if(GPIO_ReadOutputDataBit(GPIOB, GPIO_Pin_5) == Bit_RESET){
				sendcmdPropStatus(1);
		 }else{
				sendcmdPropStatus(0);
		 }	
	}	
}

/*************************************************************************** 
Function....: initLedKeyAndConnectWifiKey
Description.: PE3: ConnectWifiKey, PE4:LedKey 
Parameters..: NONE 
Return......: NONE  
****************************************************************************/

void initLedKeyAndConnectWifiKey(void)
{
		NVIC_InitTypeDef NVIC_InitStructure;
		EXTI_InitTypeDef EXTI_InitStructure;
	  GPIO_InitTypeDef GPIO_InitStructure;
	
	  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE, ENABLE); // enable GPIOE
	  NVIC_InitStructure.NVIC_IRQChannel = EXTI3_IRQn;
	  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	  NVIC_Init(&NVIC_InitStructure);		
	
	  NVIC_InitStructure.NVIC_IRQChannel = EXTI4_IRQn;
	  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
	  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	  NVIC_Init(&NVIC_InitStructure);
	
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;									 // PE3 connect GND,choose pull up resistor
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;                   
		GPIO_Init(GPIOE, &GPIO_InitStructure);
		GPIO_EXTILineConfig(GPIO_PortSourceGPIOE,GPIO_PinSource3);
		
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;              // PE4 connect GND,choose pull up resistor
		GPIO_Init(GPIOE, &GPIO_InitStructure);
		GPIO_EXTILineConfig(GPIO_PortSourceGPIOE,GPIO_PinSource4);	
	
	  EXTI_InitStructure.EXTI_Line = EXTI_Line3;
	  EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	  EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;    // PE3 connect GND,choose falling edge
	  EXTI_InitStructure.EXTI_LineCmd = ENABLE;
		EXTI_Init(&EXTI_InitStructure);
		
	  EXTI_InitStructure.EXTI_Line = EXTI_Line4;
	  EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	  EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;   // PE4 connect GND,choose falling edge
	  EXTI_InitStructure.EXTI_LineCmd = ENABLE;
		EXTI_Init(&EXTI_InitStructure);		
}

/*************************************************************************** 
Function....: initFacTestKey
Description.: PA0: factory test key 
Parameters..: NONE 
Return......: NONE  
****************************************************************************/

void initFacTestKey(void)
{
		NVIC_InitTypeDef NVIC_InitStructure;
		EXTI_InitTypeDef EXTI_InitStructure;
	  GPIO_InitTypeDef GPIO_InitStructure;
	  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);    // enable GPIOA

	  NVIC_InitStructure.NVIC_IRQChannel = EXTI0_IRQn;
	  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;
	  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	  NVIC_Init(&NVIC_InitStructure);
		
		GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
		GPIO_Init(GPIOA, &GPIO_InitStructure);
		GPIO_EXTILineConfig(GPIO_PortSourceGPIOA,GPIO_PinSource0);	
	
	  EXTI_InitStructure.EXTI_Line = EXTI_Line0;
	  EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	  EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;
	  EXTI_InitStructure.EXTI_LineCmd = ENABLE;
		EXTI_Init(&EXTI_InitStructure);
		
}

/*************************************************************************** 
Function....: checkControlBtn
Description.: one is connecting wifi ,another is testing wifi module wether work normally or not
Parameters..: NONE 
Return......: NONE  
****************************************************************************/

void checkControlBtn(void)
{
		if(connectFlg == 1)
		{
				connectFlg = 0;
			  sendCmdSetModuleConnect();
		}
		if(facTestFlg == 1)
		{
				facTestFlg = 0;
			  sendCmdSetModuleFacTest();
		}
}
/*************************************************************************** 
Function....: uploadInitialStatus
Description.: Upload status of electronic-controlled module during initialize
Parameters..: NONE 
Return......: NONE  
****************************************************************************/
void uploadInitialStatus(void)
{
		sendcmdPropStatus(1);
}

