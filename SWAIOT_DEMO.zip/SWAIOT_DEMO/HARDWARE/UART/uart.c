/**
* Copyright(C),Skyworth Group Co.,Ltd  
* Author: xumeilin@skyworth.com
* Review and doc: dengxuechao@skyworth.com dengxuechao509@qq.com
* Version:  0.2.1
* MIT Licensed
*
* MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
* MMMMM:.........MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM....MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
* MMMN...........MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM ...MMMMMMMMMMMMMMMMMMMMMMMMM . MMMMM
* MMM.... MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM ...MMMMM
* MMM ...MMMMMMMMMM  ..MMMMMMM....:MMMMMMM ..$MMM,........,MMMMMM ...MMMMMMMM ......MMMMMM .........MM
* MMM. .  OMMMMMMMMM . +MMMMMM.....MMMMMM ...MMM .. , ......NMMMM ...MMMMM  ..........NMMM..........MM
* MMMMM ....NMMMMMMM....MMMMM .....MMMMM ...MMMMMMMMMMMMD....MMMM ...MMMM....~MMMMM ...=MMMM,...MMMMMM
* MMMMMM=....,MMMMMMM ..IMMMD .. ...MMMM ..MMMMMMMMMMMMM ....MMMM ...MMM ...MMMMMMMM ...MMMM ...MMMMMM
* MMMMMMMM  ... MMMMM....MMM...MM ..MMM .. MMMMMMM ......... MMMD....MMM ...MMMMMMMM ...MMMM....MMMMMM
* MMMMMMMMMM  .. MMMMM...?M,.. MM....M=...MMMMM ... .?MM8...8MMM~...?MMM....MMMMMMMM ...MMMM....MMMMMM
* MMMMMMMMMMM. ..MMMMM~...M ..MMMM ..M...MMMMM ...MMMMMM:...MMMM ...?MMM....MMMMMMMM ...MMMM ...MMMMMM
* MM :MNMMMM.....MMMMMM .....OMMMM......?MMMMM....MMMMMM....MMMM....?MMMM....MMMMM, ...MMMMM ...8MMMMM
* MM . .........MMMMMMMM,....MMMMM:.... MMMMMM  ......,M....MMMM ...MMMMMM  ......... MMMMMM  ......MM
* MMMI.. . . ZMMMMMMMMMM ...MMMMMMM ...MMMMMMMMN  ....MM....MMMM....MMMMMMMM7. ... MMMMMMMMMM$. .  ,MM
* MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
**/

#include "uart.h"
#include "iot_user_config.h"

/*************************************************************************** 
Function....: initUSART2 
Description.: Choose USART2,init related GPIO
Parameters..: NONE  
Return......: NONE  
****************************************************************************/ 

void initUSART2(void)
{
	  GPIO_InitTypeDef GPIO_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;
    USART_InitTypeDef USART_InitStructure;
    
    /* Enable the USART2 Pins Software Remapping */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_AFIO, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2|RCC_APB2Periph_AFIO, ENABLE); 
    
    /* Configure USART2 Rx (PA.03) as input floating */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;    
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    
    /* Configure USART2 Tx (PA.02) as alternate function push-pull */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
    
    /* Enable the USART2 Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);    
    
    USART_InitStructure.USART_BaudRate = 9600;              // set baurdrate  
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;     
    USART_InitStructure.USART_Parity = USART_Parity_No;        
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;      
    
    USART_Init(USART2, &USART_InitStructure);
    USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);
    /* Enable USART2 */
    USART_Cmd(USART2, ENABLE);
		
}

/*************************************************************************** 
Function....: sendByte
Description.: Choose USARTx, send a byte
Parameters..: USART_TypeDef *USARTx:USART1/USART2/UART3/UART4, u16 byte:data
Return......: NONE  
****************************************************************************/
void sendByte(USART_TypeDef *USARTx, u16 byte)
{
	  USART_ClearFlag(USARTx, USART_FLAG_TC);             //软件清除发送完成标志位
    USART_SendData(USARTx, byte);                       //发送一个字节
    while (!USART_GetFlagStatus(USARTx, USART_FLAG_TC));//等待发送完成
    USART_ClearFlag(USARTx, USART_FLAG_TC);             //软件清除发送完成标志位
}

/*************************************************************************** 
Function....: sendStringUSART2
Description.: Choose USART2, send string
Parameters..: unsigned char *str: string, unsigned char length:length of string
Return......: NONE  
****************************************************************************/
void sendStringUSART2( char *str,unsigned char length)
{
    unsigned char i = 0;
	  for(i = 0; i<length;i++)
		{
				sendByte(USART2,*str);
			  str++;
		}
}

/*************************************************************************** 
Function....: USART2_IRQHandler
Description.: USART2 interrupt handler 
Parameters..: NONE 
Return......: NONE  
****************************************************************************/
void USART2_IRQHandler(void)
{
	if(USART_GetITStatus(USART2,USART_IT_RXNE))
	{		  
		  // add swaiotPushUartData(data);
		  swaiotPushUartData(USART_ReceiveData(USART2));
	} 
}

