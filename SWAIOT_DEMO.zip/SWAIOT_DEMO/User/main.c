/**
* Copyright(C),Skyworth Group Co.,Ltd  
* Author: xumeilin@skyworth.com
* Review and doc: dengxuechao@skyworth.com dengxuechao509@qq.com
* Version:  0.2.1
* MIT Licensed
*
* MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
* MMMMM:.........MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM....MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
* MMMN...........MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM ...MMMMMMMMMMMMMMMMMMMMMMMMM . MMMMM
* MMM.... MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM ...MMMMM
* MMM ...MMMMMMMMMM  ..MMMMMMM....:MMMMMMM ..$MMM,........,MMMMMM ...MMMMMMMM ......MMMMMM .........MM
* MMM. .  OMMMMMMMMM . +MMMMMM.....MMMMMM ...MMM .. , ......NMMMM ...MMMMM  ..........NMMM..........MM
* MMMMM ....NMMMMMMM....MMMMM .....MMMMM ...MMMMMMMMMMMMD....MMMM ...MMMM....~MMMMM ...=MMMM,...MMMMMM
* MMMMMM=....,MMMMMMM ..IMMMD .. ...MMMM ..MMMMMMMMMMMMM ....MMMM ...MMM ...MMMMMMMM ...MMMM ...MMMMMM
* MMMMMMMM  ... MMMMM....MMM...MM ..MMM .. MMMMMMM ......... MMMD....MMM ...MMMMMMMM ...MMMM....MMMMMM
* MMMMMMMMMM  .. MMMMM...?M,.. MM....M=...MMMMM ... .?MM8...8MMM~...?MMM....MMMMMMMM ...MMMM....MMMMMM
* MMMMMMMMMMM. ..MMMMM~...M ..MMMM ..M...MMMMM ...MMMMMM:...MMMM ...?MMM....MMMMMMMM ...MMMM ...MMMMMM
* MM :MNMMMM.....MMMMMM .....OMMMM......?MMMMM....MMMMMM....MMMM....?MMMM....MMMMM, ...MMMMM ...8MMMMM
* MM . .........MMMMMMMM,....MMMMM:.... MMMMMM  ......,M....MMMM ...MMMMMM  ......... MMMMMM  ......MM
* MMMI.. . . ZMMMMMMMMMM ...MMMMMMM ...MMMMMMMMN  ....MM....MMMM....MMMMMMMM7. ... MMMMMMMMMM$. .  ,MM
* MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
**/
#include "uart.h"
#include "led.h"
#include "iot_user_config.h"

uint8_t sn_num[32]={0x00};
char  ver_mcu[4]={1,0,0,0};
char *type_mcu = "STM32F103";
int main(void)
{
  initSysTick();  // ��ʼ��Systick��ʱ��
  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);	
  initUSART2();
  initLED();
  initLedKeyAndConnectWifiKey();
  initFacTestKey();
  initIotCore(ver_mcu,type_mcu,sn_num);  // ���û��ʹ���ǻ��������������Բ�ִ�г�ʼ�����
  uploadInitialStatus();
  while (1){
    checkLedStatus();
    checkControlBtn();			
    if(frame_10Hz ==1){
      frame_10Hz = 0;
      swaiotEventHandler_10HZ();
    }
  }
}

