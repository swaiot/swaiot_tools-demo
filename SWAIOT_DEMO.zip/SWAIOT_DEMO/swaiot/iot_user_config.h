/**
* Copyright(C),Skyworth Group Co.,Ltd  
* Author: dengxuechao@skyworth.com dengxuechao509@qq.com
* Review and doc: xumeilin@skyworth.com
* Version:  0.2.1
* MIT Licensed
*
* MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
* MMMMM:.........MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM....MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
* MMMN...........MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM ...MMMMMMMMMMMMMMMMMMMMMMMMM . MMMMM
* MMM.... MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM ...MMMMM
* MMM ...MMMMMMMMMM  ..MMMMMMM....:MMMMMMM ..$MMM,........,MMMMMM ...MMMMMMMM ......MMMMMM .........MM
* MMM. .  OMMMMMMMMM . +MMMMMM.....MMMMMM ...MMM .. , ......NMMMM ...MMMMM  ..........NMMM..........MM
* MMMMM ....NMMMMMMM....MMMMM .....MMMMM ...MMMMMMMMMMMMD....MMMM ...MMMM....~MMMMM ...=MMMM,...MMMMMM
* MMMMMM=....,MMMMMMM ..IMMMD .. ...MMMM ..MMMMMMMMMMMMM ....MMMM ...MMM ...MMMMMMMM ...MMMM ...MMMMMM
* MMMMMMMM  ... MMMMM....MMM...MM ..MMM .. MMMMMMM ......... MMMD....MMM ...MMMMMMMM ...MMMM....MMMMMM
* MMMMMMMMMM  .. MMMMM...?M,.. MM....M=...MMMMM ... .?MM8...8MMM~...?MMM....MMMMMMMM ...MMMM....MMMMMM
* MMMMMMMMMMM. ..MMMMM~...M ..MMMM ..M...MMMMM ...MMMMMM:...MMMM ...?MMM....MMMMMMMM ...MMMM ...MMMMMM
* MM :MNMMMM.....MMMMMM .....OMMMM......?MMMMM....MMMMMM....MMMM....?MMMM....MMMMM, ...MMMMM ...8MMMMM
* MM . .........MMMMMMMM,....MMMMM:.... MMMMMM  ......,M....MMMM ...MMMMMM  ......... MMMMMM  ......MM
* MMMI.. . . ZMMMMMMMMMM ...MMMMMMM ...MMMMMMMMN  ....MM....MMMM....MMMMMMMM7. ... MMMMMMMMMM$. .  ,MM
* MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
**/

#ifndef __IOT_USER_CONFIG_H__
#define __IOT_USER_CONFIG_H__
#include "stdio.h"
#include "iot_config.h"


// Add header file of serial port sending function or declaration of serial port sending function 
#include "uart.h"

// Replace "// uart_write_bytes(dataP, dataSize)" with serial port sending function of your platform 
// "Datap" is a char * array, and "datasize" is the array length 
/** Define of serial port sending function. "Datap" is a char * array, and "datasize" is the array length **/
#define SEND_TO_NET_CMD(dataP, dataSize)      sendStringUSART2(dataP,dataSize)


// extern function
/**
Get mask for system events
**/
#define getSysUploadMasksP() (&sysMask)
/**
Get mask for extended events
**/
#define getExtUploadMasksP() (&extMask)
extern EXT_DATA_TYPE unsigned long sysMask;
extern EXT_DATA_TYPE unsigned long extMask;
/**
init Iot core
**/
/***************************************************************************
Function....: initIotCore
Description.: initial firmware version(pointer of 4Bytes buffer) ; MCU's Type description (string); IOT's serial number(pointer of 32Bytes buffer)
Parameters..: version, firmware version(pointer of 4Bytes buffer)
Parameters..: platformName, String ending with 0 
Parameters..: serialNumber, pointer of 32Bytes buffer
Return......: NONE
****************************************************************************/
extern void initIotCore(char *version, char *platformName, unsigned char *serialNumber);
/**
Timing function of automatic parsing
**/
/***************************************************************************
Function....: swaiotEventHandler_10HZ
Description.: Timing function of automatic parsing, send command to module
Parameters..: NONE
Return......: NONE
****************************************************************************/
extern void swaiotEventHandler_10HZ(void);
/**
Receive and analyze uart data
**/
/***************************************************************************
Function....: swaiotPushUartData
Description.: Receive and analyze uart data
Parameters..: byte, enter a byte from uart register
Return......: NONE
****************************************************************************/
extern void swaiotPushUartData(unsigned char byte);
/**
Event detection interface of manual sending mode
**/
extern unsigned char checkAndCleanUploadMaskBit(unsigned long Bit, unsigned long *masks);


/***************************************************************************
 * Module system function begin
****************************************************************************/

#ifdef LISTENER_MODULE_STATUS 
/*************************************************************************** 
Function....: sendCmdGetModuleState 
Description.: get module state
Parameters..: NONE 
Return......: NONE 
Explain.....: NONE 
****************************************************************************/ 
extern void sendCmdGetModuleState(void); 
#endif 
 
/*************************************************************************** 
Function....: sendCmdSetModuleConnect 
Description.: set module to connect mode 
Parameters..: NONE 
Return......: NONE 
Explain.....: NONE 
****************************************************************************/ 
extern void sendCmdSetModuleConnect(void); 
/*************************************************************************** 
Function....: sendCmdSetModuleFacTest 
Description.: set module to factory test mode 
Parameters..: NONE 
Return......: NONE 
Explain.....: NONE 
****************************************************************************/ 
extern void sendCmdSetModuleFacTest(void); 
/*************************************************************************** 
Function....: sendCmdSetModuleUnbind 
Description.: set module to forced unbind mode 
Parameters..: NONE 
Return......: NONE 
Explain.....: NONE 
****************************************************************************/ 
extern void sendCmdSetModuleUnbind(void); 
 
// ext cmd 
/*************************************************************************** 
 * Update property function begin 
****************************************************************************/ 
#ifdef CMD_MASK_PROD_STATUS 
/*************************************************************************** 
Function....: sendcmdPropStatus 
Description.: update property STATUS
Parameters..: value, property of type unsigned char 
Return......: NONE 
Explain.....: NONE 
****************************************************************************/ 
extern void sendcmdPropStatus(unsigned char value);
#endif 



#endif

