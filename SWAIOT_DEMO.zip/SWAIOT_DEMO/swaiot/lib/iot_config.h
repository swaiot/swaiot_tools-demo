/**
* Copyright(C),Skyworth Group Co.,Ltd  
* Author: dengxuechao@skyworth.com dengxuechao509@qq.com
* Review and doc: xumeilin@skyworth.com
* Version:  0.2.1
* MIT Licensed
*
* MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
* MMMMM:.........MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM....MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
* MMMN...........MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM ...MMMMMMMMMMMMMMMMMMMMMMMMM . MMMMM
* MMM.... MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM ...MMMMM
* MMM ...MMMMMMMMMM  ..MMMMMMM....:MMMMMMM ..$MMM,........,MMMMMM ...MMMMMMMM ......MMMMMM .........MM
* MMM. .  OMMMMMMMMM . +MMMMMM.....MMMMMM ...MMM .. , ......NMMMM ...MMMMM  ..........NMMM..........MM
* MMMMM ....NMMMMMMM....MMMMM .....MMMMM ...MMMMMMMMMMMMD....MMMM ...MMMM....~MMMMM ...=MMMM,...MMMMMM
* MMMMMM=....,MMMMMMM ..IMMMD .. ...MMMM ..MMMMMMMMMMMMM ....MMMM ...MMM ...MMMMMMMM ...MMMM ...MMMMMM
* MMMMMMMM  ... MMMMM....MMM...MM ..MMM .. MMMMMMM ......... MMMD....MMM ...MMMMMMMM ...MMMM....MMMMMM
* MMMMMMMMMM  .. MMMMM...?M,.. MM....M=...MMMMM ... .?MM8...8MMM~...?MMM....MMMMMMMM ...MMMM....MMMMMM
* MMMMMMMMMMM. ..MMMMM~...M ..MMMM ..M...MMMMM ...MMMMMM:...MMMM ...?MMM....MMMMMMMM ...MMMM ...MMMMMM
* MM :MNMMMM.....MMMMMM .....OMMMM......?MMMMM....MMMMMM....MMMM....?MMMM....MMMMM, ...MMMMM ...8MMMMM
* MM . .........MMMMMMMM,....MMMMM:.... MMMMMM  ......,M....MMMM ...MMMMMM  ......... MMMMMM  ......MM
* MMMI.. . . ZMMMMMMMMMM ...MMMMMMM ...MMMMMMMMN  ....MM....MMMM....MMMMMMMM7. ... MMMMMMMMMM$. .  ,MM
* MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
**/


#ifndef __IOT_CONFIG_H__
#define __IOT_CONFIG_H__
#include "iot_base.h"

/**
 *      CUSTOM INFO 
 * 
 **/
 
// platform

#undef __IOT_CONFIG_C51__ 
#define EXT_DATA_TYPE 
#undef __HAS_BIG_ENDIAN__ 
#undef SUPPORT_SERIAL_NUMBER 
#undef LISTENER_MODULE_STATUS 
#define SUPPORT_DATA_TYPE_INT8 
#undef SUPPORT_DATA_TYPE_INT16 
#undef SUPPORT_DATA_TYPE_INT32 
#undef SUPPORT_DATA_TYPE_FLOAT 
#undef SUPPORT_DATA_TYPE_STRING 
#undef SUPPORT_GET_UTC 
#undef SUPPORT_GET_SSID 
#undef SUPPORT_GET_RSSI 
#undef SUPPORT_GET_IP 
#undef SUPPORT_GET_MAC 
#undef SUPPORT_UPDATE 
#undef SUPPORT_UPDATE_BAUDRATE_HIGH_SPEED 
#undef SUPPORT_UPDATE_BAUDRATE_LOW_SPEED 

#define PROD_INFO_MODEL "CTZ-1018" 
#define PROD_INFO_TYPE 40 
#define PROD_INFO_BRAND 1 
// property 
#define CMD_MASK_PROD_STATUS BIT0 
#define PROD_STATUS_NAME "STATUS" 

// optimize 
#define SUPPORT_RECEIVE_LOOP 
#define RECEIVE_LOOP_SIZE (128) 
#define SUPPORT_DELAY_REPLY 


  #ifdef __IOT_CONFIG_C51__
    typedef char iot_s8_t;
    typedef int iot_s16_t;
    typedef long iot_s32_t;
    
    typedef unsigned char iot_u8_t;
    typedef unsigned int iot_u16_t; 
    typedef unsigned long iot_u32_t;
  #else
    typedef char iot_s8_t;
    typedef short int iot_s16_t;
    typedef int iot_s32_t;
    
    typedef unsigned char iot_u8_t;
    typedef unsigned short int iot_u16_t; //
    typedef unsigned int iot_u32_t;
  #endif
  
#endif

