/**
* Copyright(C),Skyworth Group Co.,Ltd  
* Author: dengxuechao@skyworth.com dengxuechao509@qq.com
* Version:  0.1.0
* MIT Licensed
*
* MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
* MMMMM:.........MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM....MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
* MMMN...........MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM ...MMMMMMMMMMMMMMMMMMMMMMMMM . MMMMM
* MMM.... MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM ...MMMMM
* MMM ...MMMMMMMMMM  ..MMMMMMM....:MMMMMMM ..$MMM,........,MMMMMM ...MMMMMMMM ......MMMMMM .........MM
* MMM. .  OMMMMMMMMM . +MMMMMM.....MMMMMM ...MMM .. , ......NMMMM ...MMMMM  ..........NMMM..........MM
* MMMMM ....NMMMMMMM....MMMMM .....MMMMM ...MMMMMMMMMMMMD....MMMM ...MMMM....~MMMMM ...=MMMM,...MMMMMM
* MMMMMM=....,MMMMMMM ..IMMMD .. ...MMMM ..MMMMMMMMMMMMM ....MMMM ...MMM ...MMMMMMMM ...MMMM ...MMMMMM
* MMMMMMMM  ... MMMMM....MMM...MM ..MMM .. MMMMMMM ......... MMMD....MMM ...MMMMMMMM ...MMMM....MMMMMM
* MMMMMMMMMM  .. MMMMM...?M,.. MM....M=...MMMMM ... .?MM8...8MMM~...?MMM....MMMMMMMM ...MMMM....MMMMMM
* MMMMMMMMMMM. ..MMMMM~...M ..MMMM ..M...MMMMM ...MMMMMM:...MMMM ...?MMM....MMMMMMMM ...MMMM ...MMMMMM
* MM :MNMMMM.....MMMMMM .....OMMMM......?MMMMM....MMMMMM....MMMM....?MMMM....MMMMM, ...MMMMM ...8MMMMM
* MM . .........MMMMMMMM,....MMMMM:.... MMMMMM  ......,M....MMMM ...MMMMMM  ......... MMMMMM  ......MM
* MMMI.. . . ZMMMMMMMMMM ...MMMMMMM ...MMMMMMMMN  ....MM....MMMM....MMMMMMMM7. ... MMMMMMMMMM$. .  ,MM
* MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
**/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "iot_core.h"
#include "iot_interface.h"
#include "iot_base.h"
#include "iot_user_config.h"

#define calcCmdLen(value) (char)(10 + (value))

EXT_DATA_TYPE unsigned long sysMask = 0;
EXT_DATA_TYPE unsigned long extMask = 0;
EXT_DATA_TYPE char *ver;
EXT_DATA_TYPE char *platform;
EXT_DATA_TYPE unsigned char *sn;
#ifdef SUPPORT_UPDATE
EXT_DATA_TYPE iot_u32_t packNumber;
char *makeSysReplyUpdate(char state, iot_u32_t packNumber);
#endif

// char calcCmdLen(char dataLen);
void calcCRCToDataLine(char *dataLine);

float parsSkyParamFloat(unsigned char *address);
char *parsSkyParamStr(char *address);
iot_u32_t parsSkyParamInt(char *address, char type);
char getProdInfoFlg(void);

void parsSkyParam(iot_u8_t *dataLine, iot_u8_t len);

iot_u16_t GetCRC16(volatile iot_u8_t *buf, iot_u16_t length);
void decoderSkyCmd(unsigned char value);
void decoderLoopData(void);
unsigned char *codeSkyParamS32(iot_u32_t Data);
//unsigned char *codeSkyParamS16(iot_u16_t Data);
unsigned char *codeSkyParamF32(float *Data_p);
char *makeReplyVersion(char *version, char *name);
/***************************************************************************
Function....: initIotCore
Description.: initial firmware version(pointer of 4Bytes buffer) ,MCU's type(string),IOT's serial number(pointer of 32Bytes buffer)
Parameters..: version ,firmware version(pointer of 4Bytes buffer)
Parameters..: platformName ,String ending with \0
Parameters..: serialNumber ,pointer of 32Bytes buffer
Return......: NONE
****************************************************************************/
void initIotCore(char *version, char *platformName, unsigned char *serialNumber)
{
  ver = version;
  platform = platformName;
  sn = serialNumber;
}

/***************************************************************************
Function....: sendSkyProdCmdToModule
Description.: decode commands
Parameters..: NONE
Return......: NONE
****************************************************************************/
void sendSkyProdCmdToModule()
{
  // #ifndef SUPPORT_DELAY_REPLY // close
  //   return;
  // #else
  char *sendCmdLine = 0;
#ifdef SUPPORT_SERIAL_NUMBER
  if (checkAndCleanUploadMaskBit(CMD_UPLOAD_MASK_HEART_BEAT, getSysUploadMasksP()) == 1) // heart beat mask have set, replay heart beat to electronic-controlled module and clean the mask
  {
    sendCmdLine = makeSysReply(SKY_FEEDBACK_HEART_BEAT, SKY_CMD_PARAAM_NULL, NULL, 0);
  }
  else if (checkAndCleanUploadMaskBit(CMD_UPLOAD_MASK_FEEDBACK_SERIAL_NUMBER, getSysUploadMasksP()) == 1) // serial number mask have set, replay serial number to electronic-controlled module and clean the mask
  {
    sendCmdLine = makeSysReply(
        SKY_FEEDBACK_SERIAL_NUMBER, //  command name
        SKY_CMD_PARAAM_S32,         //  comand type
        sn,                         //  command value
        32);                        //  length of value
  }
  else
#endif
      if (checkAndCleanUploadMaskBit(CMD_UPLOAD_MASK_PROD_TYPE, getSysUploadMasksP()) == 1) // product type  mask have set, upload to wifi module and clean the mask
  {
    sendCmdLine = makeSysReply(
        SKY_FEEDBACK_PRODUCT_TYPE,       //  command name
        SKY_CMD_PARAAM_S32,              //  comand type
        codeSkyParamS32(PROD_INFO_TYPE), //  command value
        4);                              //  length of value
  }
  else if (checkAndCleanUploadMaskBit(CMD_UPLOAD_MASK_PROD_MODEL, getSysUploadMasksP()) == 1) // product model mask have set, upload to wifi module and clean the mask
  {
    sendCmdLine = makeSysReply(
        SKY_FEEDBACK_PRODUCT_MODEL,       //  command name
        SKY_CMD_PARAAM_STR,               //  comand type
        (unsigned char *)PROD_INFO_MODEL, //  command value
        strlen(PROD_INFO_MODEL));         //  length of value
  }
  else if (checkAndCleanUploadMaskBit(CMD_UPLOAD_MASK_PROD_BRAND, getSysUploadMasksP()) == 1) // product brand mask have set, upload to wifi module and clean the mask
  {
    sendCmdLine = makeSysReply(
        SKY_FEEDBACK_PRODUCT_BRAND,       //  command name
        SKY_CMD_PARAAM_S32,               //  comand type
        codeSkyParamS32(PROD_INFO_BRAND), //  command value
        4);                               //  length of value
  }
#ifdef SUPPORT_GET_UTC
  else if (checkAndCleanUploadMaskBit(CMD_UPLOAD_MASK_REQUEST_TIME, getSysUploadMasksP()) == 1) // utc mask have set, upload to wifi module and clean the mask
  {
    sendCmdLine = makeSysReply(
        SKY_DEMAND_CURRENT_TIME,
        SKY_CMD_PARAAM_NULL,
        NULL,
        0);
  }
#endif
  else if (checkAndCleanUploadMaskBit(CMD_UPLOAD_MASK_REQUEST_NETSTATE, getSysUploadMasksP()) == 1) // request net state mask have set, upload to wifi module and clean the mask
  {
    sendCmdLine = makeSysReply(
        SKY_DEMAND_STA_STATE,
        SKY_CMD_PARAAM_NULL,
        NULL, 0);
  }
  else if (checkAndCleanUploadMaskBit(CMD_UPLOAD_MASK_REQUEST_CONNECT, getSysUploadMasksP()) == 1) // request connect net mask have set, upload to wifi module and clean the mask
  {
    sendCmdLine = makeSysReply(
        SKY_ORDER_CONFIG_WIFI,
        SKY_CMD_PARAAM_NULL,
        NULL, 0);
  }
  else if (checkAndCleanUploadMaskBit(CMD_UPLOAD_MASK_REQUEST_FAC, getSysUploadMasksP()) == 1) // request wifi factotry test mask have set, upload to wifi module and clean the mask
  {
    sendCmdLine = makeSysReply(
        SKY_ORDER_FACTORY_MODE,
        SKY_CMD_PARAAM_NULL,
        NULL, 0);
  }
  else if (checkAndCleanUploadMaskBit(CMD_UPLOAD_MASK_REQUEST_UNBIND, getSysUploadMasksP()) == 1) // request unbind app mask have set, upload to wifi module and clean the mask
  {
    sendCmdLine = makeSysReply(
        SKY_ORDER_FORCE_UNBIND,
        SKY_CMD_PARAAM_NULL,
        NULL, 0);
  }
#ifdef SUPPORT_GET_IP
  else if (checkAndCleanUploadMaskBit(CMD_UPLOAD_MASK_REQUEST_IP, getSysUploadMasksP()) == 1) // request wifi IP mask have set, upload to wifi module and clean the mask
  {
    sendCmdLine = makeSysReply(SKY_ORDER_CURRENT_IP, SKY_CMD_PARAAM_NULL, NULL, 0);
  }
#endif
#ifdef SUPPORT_GET_SSID
  else if (checkAndCleanUploadMaskBit(CMD_UPLOAD_MASK_REQUEST_SSID, getSysUploadMasksP()) == 1) // request router's name mask have set, upload to wifi module and clean the mask
  {
    sendCmdLine = makeSysReply(SKY_ORDER_CURRENT_SSID, SKY_CMD_PARAAM_NULL, NULL, 0);
  }
#endif
#ifdef SUPPORT_GET_MAC
  else if (checkAndCleanUploadMaskBit(CMD_UPLOAD_MASK_REQUEST_MAC, getSysUploadMasksP()) == 1) // request wifi module's mac mask have set, upload to wifi module and clean the mask
  {
    sendCmdLine = makeSysReply(SKY_ORDER_STA_MAC, SKY_CMD_PARAAM_NULL, NULL, 0);
  }
#endif
#ifdef SUPPORT_GET_RSSI
  else if (checkAndCleanUploadMaskBit(CMD_UPLOAD_MASK_REQUEST_RSSI, getSysUploadMasksP()) == 1) // request strength of wifi signal mask have set, upload to wifi module and clean the mask
  {
    sendCmdLine = makeSysReply(SKY_ORDER_SIGNAL_RSSI, SKY_CMD_PARAAM_NULL, NULL, 0);
  }
#endif
  /* for skyworth pad and  update. */
  else if (checkAndCleanUploadMaskBit(CMD_UPLOAD_MASK_FEEDBACK_VER, getSysUploadMasksP()) == 1) // request version mask have set, upload to wifi module and clean the mask
  {
    sendCmdLine = makeReplyVersion(ver, platform);
  }

  // //     else if(checkAndCleanUploadMaskBit(CMD_UPLOAD_MASK_FEEDBACK_VVER, getSysUploadMasksP()) == 1){}
#ifdef SUPPORT_UPDATE
  else if (checkAndCleanUploadMaskBit(CMD_UPLOAD_MASK_FEEDBACK_UPDATESTATE, getSysUploadMasksP()) == 1)
  {
    sendCmdLine = makeSysReply(SKY_FEEDBACK_PRODUCT_UPGRADE_SUPP, SKY_CMD_PARAAM_S8, codeSkyParamS32(0), 1);
  }
  //     else if(checkAndCleanUploadMaskBit(CMD_UPLOAD_MASK_FEEDBACK_VUPDATESTATE, getSysUploadMasksP()) == 1){ }
  else if (checkAndCleanUploadMaskBit(CMD_UPLOAD_MASK_FEEDBACK_BAUDSTATE_WISH, getSysUploadMasksP()) == 1)
  {
#ifdef SUPPORT_UPDATE_BAUDRATE_HIGH_SPEED
    sendCmdLine = makeSysReply(SKY_FEEDBACK_UPGRADE_BAUD_RATE, SKY_CMD_PARAAM_S16, codeSkyParamS32(0x0101), 2); // 01,01 is 115200.use codeSkyParamS32 to string
#else
#ifdef SUPPORT_UPDATE_BAUDRATE_LOW_SPEED
    sendCmdLine = makeSysReply(SKY_FEEDBACK_UPGRADE_BAUD_RATE, SKY_CMD_PARAAM_S16, codeSkyParamS32(0x0100), 2); // 01,01 is 115200.use codeSkyParamS32 to string
#endif
#endif
  }
  else if (checkAndCleanUploadMaskBit(CMD_UPLOAD_MASK_FEEDBACK_BAUDSTATE, getSysUploadMasksP()) == 1)
  {
#ifdef SUPPORT_UPDATE_BAUDRATE_HIGH_SPEED
    sendCmdLine = makeSysReply(SKY_FEEDBACK_UPGRADE_BAUD_RATE, SKY_CMD_PARAAM_S16, codeSkyParamS32(0x0201), 2); // 01,01 is 115200.use codeSkyParamS32 to string
#else
#ifdef SUPPORT_UPDATE_BAUDRATE_LOW_SPEED
    sendCmdLine = makeSysReply(SKY_FEEDBACK_UPGRADE_BAUD_RATE, SKY_CMD_PARAAM_S16, codeSkyParamS32(0x0200), 2); // 00,01 is 9600.use codeSkyParamS32 to string
#endif
#endif
    if (0 != sendCmdLine)
    {
      SEND_TO_NET_CMD(sendCmdLine, sendCmdLine[SKY_CMD_ADDRESS_DATALEN]);
    }
    changeUpdateRate();
    return;
  }
  else if (checkAndCleanUploadMaskBit(CMD_UPLOAD_MASK_FEEDBACK_DATAOVER, getSysUploadMasksP()) == 1)
  {
    sendCmdLine = makeSysReplyUpdate(0, packNumber); // custom to updae
  }
  //     else if(checkAndCleanUploadMaskBit(CMD_UPLOAD_MASK_FEEDBACK_VDATAOVER, getSysUploadMasksP()) == 1){}
#endif
  else
  {
    sendCmdLine = makeExtCmdToModule();
  }
  if (0 != sendCmdLine)
  {
    SEND_TO_NET_CMD(sendCmdLine, sendCmdLine[SKY_CMD_ADDRESS_DATALEN]);
  }
  // #endif
}
// ver 0x0A
/***************************************************************************
Function....: parsSkyParam
Description.: match communication instruction,module set relevant mask
Parameters..: iot_u8_t *dataLine: array buffer  iot_u8_t len:length of array
Return......: NONE
****************************************************************************/
void parsSkyParam(iot_u8_t *dataLine, iot_u8_t len)
{
  char propTypeOffset, *propValue_p /*, *sendCmdLine , cmdDataTmp[6]*/; // Except for long and float types, the maximum buffer space for other types is 4 byte.
  unsigned long *paramMaskFlage;
  // judge source address and command code
  if (SKY_CMD_DATA_SOURCE_THINGS == dataLine[SKY_CMD_ADDRESS_TAGNUM] // source address :0xf1
                                                                     //            && SKY_CMD_DATA_SOURCE_STA == dataLine[SKY_CMD_ADDRESS_SOUNUM]        //
      && SKY_CMD_DATA_CMDVER == dataLine[SKY_CMD_ADDRESS_CMDVER])    // command code :0x0a
  {
    switch (dataLine[SKY_CMD_ADDRESS_CMD]) //  judge the ninth command
    {
#ifdef SUPPORT_SERIAL_NUMBER
    case SKY_GET_HEART_BEAT:                                              // 0x00: electronic-controlled module get heartbeat ,smart screen send heartbeat to device per 500ms
      setUploadMaskBit(CMD_UPLOAD_MASK_HEART_BEAT, getSysUploadMasksP()); // set heartbeat mask ,get heartbeat form samrt screen
      break;
    case SKY_GET_SERIAL_NUMBER:                                                       // 0x14: electronic-controlled module get serial number,smart screen send serial number to device
      setUploadMaskBit(CMD_UPLOAD_MASK_FEEDBACK_SERIAL_NUMBER, getSysUploadMasksP()); // set serial number mask,get serial number form samrt screen
      break;
    case SKY_SET_SERIAL_NUMBER: // 0x15: electronic-controlled module feedback serial number to smart screen
      moduleSetSerialNumber((char *)(dataLine + SKY_CMD_ADDRESS_CMDDATA));
      break;
#endif
    case SKY_GET_PRODUCT_TYPE:                                           // 0x01: electronic-controlled module upload product type to wifi   ex:type 40 is a lamp
      setUploadMaskBit(CMD_UPLOAD_MASK_PROD_TYPE, getSysUploadMasksP()); // module set product type mask
      break;
    case SKY_GET_PRODUCT_MODEL:                                           // 0x02: electronic-controlled module upload product model to wifi, ex: model "CZT-1018" is lamp's name
      setUploadMaskBit(CMD_UPLOAD_MASK_PROD_MODEL, getSysUploadMasksP()); // module set product model mask
      break;
    case SKY_GET_PRODUCT_BRAND:                                           // 0x03: electronic-controlled module upload product brand to wifi  ex:brand 1 is skyworth
      setUploadMaskBit(CMD_UPLOAD_MASK_PROD_BRAND, getSysUploadMasksP()); // module set product brand mask
      break;
    case SKY_SET_A_PARAM:                                                                                  // 0x04: electronic-controlled module communication instruction to wifi
      propTypeOffset = strlen((char *)(dataLine + SKY_CMD_ADDRESS_CMDDATA)) + 1 + SKY_CMD_ADDRESS_CMDDATA; // prop type
      propValue_p = (char *)(dataLine + propTypeOffset + 1);                                               //
      switch (dataLine[(int)propTypeOffset])                                                               // data type
      {
#ifdef SUPPORT_DATA_TYPE_INT8
      case SKY_CMD_PARAAM_S8:                                                                   // 0x80: char 1byte
        receiveAPropS8((char *)(dataLine + SKY_CMD_ADDRESS_CMDDATA), (iot_s8_t)propValue_p[0]); // electronic-controlled module decode
        break;
#endif
#ifdef SUPPORT_DATA_TYPE_INT16
      case SKY_CMD_PARAAM_S16:                                                                                                      // 0x81: short 2byte
        receiveAPropS16((char *)(dataLine + SKY_CMD_ADDRESS_CMDDATA), (iot_s16_t)parsSkyParamInt(propValue_p, SKY_CMD_PARAAM_S16)); // electronic-controlled module decode
        break;
#endif
#ifdef SUPPORT_DATA_TYPE_INT32
      case SKY_CMD_PARAAM_S32:                                                                                                      // 0x82: int 4byte
        receiveAPropS32((char *)(dataLine + SKY_CMD_ADDRESS_CMDDATA), (iot_s32_t)parsSkyParamInt(propValue_p, SKY_CMD_PARAAM_S32)); // electronic-controlled module decode
        break;
#endif
#ifdef SUPPORT_DATA_TYPE_FLOAT
      case SKY_CMD_PARAAM_F32:                                                                                            // 0x83: float 4byte
        receiveAPropF32((char *)(dataLine + SKY_CMD_ADDRESS_CMDDATA), parsSkyParamFloat((unsigned char *)(propValue_p))); // electronic-controlled module decode
        break;
#endif
#ifdef SUPPORT_DATA_TYPE_STRING
      case SKY_CMD_PARAAM_STR:                                                                // 0x84: string end with 0x00
        receiveAPropStr((char *)(dataLine + SKY_CMD_ADDRESS_CMDDATA), (char *)(propValue_p)); // electronic-controlled module decode
        // value =  //string
        // name =
        break;
#endif
      default:
        break;
      }
      break;
#ifdef SUPPORT_SINGLE_PROP_QUERY
    case SKY_GET_A_PARAM:
      /////////////////abandon///////////////////////////////////////////////////////////
      break;
#endif
    case SKY_GET_ALL_PARAMS:                 // 0x06: electronic-controlled module upload all property
      paramMaskFlage = getExtUploadMasksP(); // all mask set 1
      *paramMaskFlage = 0xFFFFFFFF;
      break;
#ifdef LISTENER_MODULE_STATUS // electronic-controlled module listen wifi
    case SKY_NOTIFY_CURRENT_STATE:
      moduleStateChangeHandler((ENUM_MODULE_STATE_SKY)dataLine[SKY_CMD_ADDRESS_CMDDATA]); // get all status of wifi module and handle status
      break;
#endif
#ifdef SUPPORT_GET_UTC // electronic-controlled module get utc
    case SKY_NOTIFY_CURRENT_TIME:
      moduleTimeHandler(parsSkyParamInt((char *)(dataLine + SKY_CMD_ADDRESS_CMDDATA), SKY_CMD_PARAAM_S32)); // electronic-controlled module handle utc
      break;
#endif
#ifdef SUPPORT_GET_SSID // electronic-controlled module get router's name
    case SKY_NOTIFY_CURRENT_SSID:
      moduleSSIDHandler(dataLine + SKY_CMD_ADDRESS_CMDDATA); // electronic-controlled module handle ssid
      break;
#endif
#ifdef SUPPORT_GET_RSSI // electronic-controlled module get strenth of wifi
    case SKY_NOTIFY_RSSI:
      moduleRssiHandler(dataLine[SKY_CMD_ADDRESS_CMDDATA]); // electronic-controlled module handle rssi
      break;
#endif
#ifdef SUPPORT_GET_IP // electronic-controlled module get IP
    case SKY_NOTIFY_CURRENT_IP:
      moduleIPHandler(dataLine + SKY_CMD_ADDRESS_CMDDATA); // electronic-controlled module handle ip
      break;
#endif
#ifdef SUPPORT_GET_MAC // electronic-controlled module get MAC
    case SKY_NOTIFY_STA_MAC:
      moduleMACHandler(dataLine + SKY_CMD_ADDRESS_CMDDATA); // // electronic-controlled module handle mac
      break;
#endif
    case SKY_GET_PRODUCT_VERSION:                                           // wifi module get version of electronic-controlled module
      setUploadMaskBit(CMD_UPLOAD_MASK_FEEDBACK_VER, getSysUploadMasksP()); // feedback version mask have set
      break;
// case SKY_GET_VOICE_VERSION :
//     break;
#ifdef SUPPORT_UPDATE // wifi module request electronic-controlled modul update
    case SKY_REQ_PRODUCT_UPGRADE:
      if (setFirmwareSize(parsSkyParamInt((char *)(dataLine + SKY_CMD_ADDRESS_CMDDATA), SKY_CMD_PARAAM_S32)))
      {
        setUploadMaskBit(CMD_UPLOAD_MASK_FEEDBACK_UPDATESTATE, getSysUploadMasksP()); // feedback update mask have set
      }

      break;
    // case SKY_REQ_VOICE_UPGRADE :
    //     break;
    case SKY_SET_UPGRADE_BAUD_RATE: //  wifi module negotiate baurd rate with electric control
      if (dataLine[SKY_CMD_ADDRESS_CMDDATA + 1] == SKY_CMD_FLG_BAUD_RATE_WISH)
      { // flage is data[1]
        setUploadMaskBit(CMD_UPLOAD_MASK_FEEDBACK_BAUDSTATE_WISH, getSysUploadMasksP());
      }
      else if (dataLine[SKY_CMD_ADDRESS_CMDDATA + 1] == SKY_CMD_FLG_BAUD_RATE_DECISION)
      { // flage is data[1]

        setUploadMaskBit(CMD_UPLOAD_MASK_FEEDBACK_BAUDSTATE, getSysUploadMasksP());
      }
      break;
    case SKY_SET_PRODUCT_UPGRADE_DATA:
      packNumber = (iot_s32_t)parsSkyParamInt((char *)dataLine + SKY_CMD_ADDRESS_CMDDATA, SKY_CMD_PARAAM_S32);
      updatePack(packNumber, dataLine + SKY_CMD_ADDRESS_CMDDATA + 4); // update pack is data[4]
      setUploadMaskBit(CMD_UPLOAD_MASK_FEEDBACK_DATAOVER, getSysUploadMasksP());
      break;
      // case SKY_SET_VOICE_UPGRADE_DATA :
      //     break;
#endif
    default:
      break;
    }
  }
}

/***************************************************************************
Function....: swaiotPushUartData
Description.: put data into uart register
Parameters..: unsigned char byte
Return......: NONE
****************************************************************************/

void swaiotPushUartData(unsigned char byte)
{
#ifdef SUPPORT_RECEIVE_LOOP
  pushByteToLoop(byte);
#else
  decoderSkyCmd(byte);
#endif
}

/***************************************************************************
Function....: swaiotEventHandler_10HZ
Description.: electronic-controlled modul decode command
Parameters..: unsigned char byte
Return......: NONE
****************************************************************************/
void swaiotEventHandler_10HZ(void)
{
  // #ifdef SUPPORT_DELAY_REPLY
  static EXT_DATA_TYPE char sendFlg = 0;

  sendFlg = !sendFlg;
  if (sendFlg)
  { // once in 2 cycle
    sendSkyProdCmdToModule();
  }
  // #endif

#ifdef SUPPORT_RECEIVE_LOOP
  decoderLoopData();
#endif
}

#ifdef SUPPORT_RECEIVE_LOOP
void decoderLoopData(void)
{
  unsigned char tmp = 0;
  while (getLoopDataLen())
  {
    pullLoopData(&tmp);
    decoderSkyCmd(tmp);
  }
}
#endif
/***************************************************************************
Function....: decoderSkyCmd
Description.: electronic-controlled modul decode command
Parameters..: unsigned char value
Return......: NONE
****************************************************************************/
void decoderSkyCmd(unsigned char value)
{
  static EXT_DATA_TYPE iot_u8_t tmp[SKY_CMD_DATA_MAX_LEN] = {0}; //
  static EXT_DATA_TYPE iot_u8_t tmpIndex = 0;
  static EXT_DATA_TYPE iot_u8_t cmdLen = 0;
  if (SKY_CMD_DATA_MAX_LEN <= tmpIndex)
  {
    tmpIndex = 0;
  }
  tmp[tmpIndex] = value;
  // if index and HDR can't match head 0x7a
  if ((SKY_CMD_ADDRESS_HEADA == tmpIndex && SKY_CMD_DATA_HEADA != value) || (SKY_CMD_ADDRESS_HEADB == tmpIndex && SKY_CMD_DATA_HEADB != value))
  {
    tmpIndex = 0; // interference
    return;
  }
  if (SKY_CMD_ADDRESS_DATALEN == tmpIndex) // index of packet length
  {
    cmdLen = value;                                  // get packet length
    if (SKY_CMD_DATA_MAX_LEN <= value || 0 == value) // if packet length exceed limits
    {
      tmpIndex = 0;
      cmdLen = 0;
      memset((void *)tmp, 0, SKY_CMD_DATA_MAX_LEN);
      return;
    }
  }

  if (0 < cmdLen && tmpIndex >= (cmdLen - 1))
  {                                                                                         // check cmd len
    if ((((iot_u16_t)tmp[tmpIndex] << 8) + tmp[tmpIndex - 1]) == GetCRC16(tmp, cmdLen - 2)) // add crc to array
    {
      parsSkyParam(tmp, cmdLen); // match command
    }
    tmpIndex = 0;
    memset((void *)tmp, 0, SKY_CMD_DATA_MAX_LEN); // open memory size
    return;
  }
  tmpIndex++;
}

/***************************************************************************
Function....: getToInternetBuff
Description.: stable commmand 
Parameters..: NONE
Return......: Buff
****************************************************************************/
char *getToInternetBuff()
{
  static EXT_DATA_TYPE char Buff[SKY_CMD_DATA_MAX_LEN] = {0};
  Buff[SKY_CMD_ADDRESS_HEADA] = SKY_CMD_DATA_HEADA;          // Buff[0]=0x7a
  Buff[SKY_CMD_ADDRESS_HEADB] = SKY_CMD_DATA_HEADB;          // Buff[1]=0x7a
  Buff[SKY_CMD_ADDRESS_TAGNUM] = SKY_CMD_DATA_SOURCE_STA;    // Buff[2]=0xf0
  Buff[SKY_CMD_ADDRESS_SOUNUM] = SKY_CMD_DATA_SOURCE_THINGS; // Buff[3]=0xf1
  Buff[SKY_CMD_ADDRESS_CMDID] = SKY_CMD_DATA_CMDID_THINGS;   // Buff[7]=0xf1
  return Buff;
}
/***************************************************************************
Function....: calcCRCToDataLine
Description.: add CRC to array 
Parameters..: char *dataLine : array
Return......: Buff
****************************************************************************/
void calcCRCToDataLine(char *dataLine)
{
  iot_u16_t crc16 = 0;
  char len = dataLine[SKY_CMD_ADDRESS_DATALEN];
  crc16 = GetCRC16((iot_u8_t *)dataLine, len - 2); // calc crc16
  dataLine[len - 2] = (unsigned char)crc16;        // set crc L
  dataLine[len - 1] = (unsigned char)(crc16 >> 8); // set cec H
}
/***************************************************************************
Function....: makeSysReply
Description.: electronic-controlled modul replay  to wifi module
Parameters..: char cmdType: communication command type,
Parameters..: char paramType: communication property 
Parameters..: unsigned char *Data:command value ,char datalen:length of value
Return......: put the data together
****************************************************************************/
char *makeSysReply(char cmdType, char paramType, unsigned char *Data, char datalen)
{
  iot_u8_t i = 0;
  char *tmp = getToInternetBuff();
  tmp[SKY_CMD_ADDRESS_CMDVER] = CMD_VERSION; // data 1
  tmp[SKY_CMD_ADDRESS_CMD] = cmdType;        // data 2
  if (NULL != Data)
  {
    for (i = 0; i < datalen; i++)
    {
      tmp[SKY_CMD_ADDRESS_CMDDATA + i] = Data[i];
    }
  }
  if ((char)SKY_CMD_PARAAM_STR == paramType && NULL != Data)
  {
    tmp[SKY_CMD_ADDRESS_CMDDATA + i] = 0;                   // string end with 0
    tmp[SKY_CMD_ADDRESS_DATALEN] = calcCmdLen(3 + datalen); // 3 is crc(2) + str\0 (1) = 3
  }
  else
  {
    tmp[SKY_CMD_ADDRESS_DATALEN] = calcCmdLen(2 + datalen); // There are two data sets. crc16 is 2 byte
  }

  calcCRCToDataLine(tmp);
  return tmp;
}
/***************************************************************************
Function....: makeSysReplyUpdate
Description.:  
Parameters..: 
Return......: tmp
****************************************************************************/
#ifdef SUPPORT_UPDATE
char *makeSysReplyUpdate(char state, iot_u32_t packNumber)
{
  //  iot_u8_t i = 0;
  char *tmp = getToInternetBuff();
  tmp[SKY_CMD_ADDRESS_CMDVER] = CMD_VERSION;                 // data 1
  tmp[SKY_CMD_ADDRESS_CMD] = SKY_FEEDBACK_UPGRADE_DATA_OVER; // data 2

  tmp[SKY_CMD_ADDRESS_CMDDATA] = 0;
  tmp[SKY_CMD_ADDRESS_CMDDATA + 4] = (char)((packNumber >> 24) & 0xff);
  tmp[SKY_CMD_ADDRESS_CMDDATA + 3] = (char)((packNumber >> 16) & 0xff);
  tmp[SKY_CMD_ADDRESS_CMDDATA + 2] = (char)((packNumber >> 8) & 0xff);
  tmp[SKY_CMD_ADDRESS_CMDDATA + 1] = (char)(packNumber & 0xff);
  tmp[SKY_CMD_ADDRESS_DATALEN] = calcCmdLen(7); //  crc16 is 2 byte , state +1,packNumber +4

  calcCRCToDataLine(tmp);
  return tmp;
}
#endif
/***************************************************************************
Function....: makeReplyVersion
Description.: replay firmware version and mcu of electronic-controlled module
Parameters..: char *version: firmware version ,version is 4byte
Parameters..: char *name: mcu of electronic-controlled module,string type
Return......: tmp
****************************************************************************/
// version is char [4]
char *makeReplyVersion(char *version, char *name)
{
  iot_u8_t i = 0;
  char *tmp = getToInternetBuff();
  tmp[SKY_CMD_ADDRESS_CMDVER] = CMD_VERSION;               // data 1
  tmp[SKY_CMD_ADDRESS_CMD] = SKY_FEEDBACK_PRODUCT_VERSION; // data 2

  tmp[SKY_CMD_ADDRESS_CMDDATA + 3] = version[3];
  tmp[SKY_CMD_ADDRESS_CMDDATA + 2] = version[2];
  tmp[SKY_CMD_ADDRESS_CMDDATA + 1] = version[1];
  tmp[SKY_CMD_ADDRESS_CMDDATA] = version[0];

  if (NULL != name)
  {
    for (i = 0; name[i] != 0; i++)
    {
      tmp[SKY_CMD_ADDRESS_CMDDATA + 4 + i] = name[i]; // 4 is version len
    }
  }
  tmp[SKY_CMD_ADDRESS_CMDDATA + 4 + i] = 0;         // 4 is version len ,MCU TYPE is string ,end with 0
  i += 4;                                           // 4 is version len, length of (version + mcu type)
  tmp[SKY_CMD_ADDRESS_DATALEN] = calcCmdLen(3 + i); // 3 is:( pack len - pack office)(1) + crch(+1) +crcl(+1) = 3
  calcCRCToDataLine(tmp);
  return tmp;
}

/***************************************************************************
Function....: makeInternetExtCmdSt
Description.: string type 
Parameters..: unsigned char *name :property ,char *value:content
Return......: tmp
****************************************************************************/
#ifdef SUPPORT_DATA_TYPE_STRING
char *makeInternetExtCmdStr(unsigned char *name, char *value)
{
  iot_u16_t i = 0, j = 0;
  char *tmp = getToInternetBuff();
  tmp[SKY_CMD_ADDRESS_CMDVER] = CMD_VERSION;       // data 1
  tmp[SKY_CMD_ADDRESS_CMD] = SKY_FEEDBACK_A_PARAM; // data 2
  if (NULL != name)
  {
    for (i = 0; name[i] != 0; i++)
    {
      tmp[SKY_CMD_ADDRESS_CMDDATA + i] = name[i]; // property name
    }
  }
  tmp[SKY_CMD_ADDRESS_CMDDATA + i] = 0; // property name end with 0
  i++;
  tmp[SKY_CMD_ADDRESS_CMDDATA + i] = SKY_CMD_PARAAM_STR; // 0x84  type:string
  i++;
  if (NULL != value)
  {
    for (j = 0; value[j] != 0; j++)
    {
      tmp[SKY_CMD_ADDRESS_CMDDATA + i + j] = value[j]; // value
    }
    i += j;
  }
  tmp[SKY_CMD_ADDRESS_CMDDATA + i] = 0;             // end with 0
  tmp[SKY_CMD_ADDRESS_DATALEN] = calcCmdLen(3 + i); // 3 is:( pack len - pack office)(1) + crch(+1) +crcl(+1) = 3
  calcCRCToDataLine(tmp);
  return tmp;
}
#endif

/***************************************************************************
Function....: makeInternetExtCmdS8
Description.: char  type 
Parameters..: unsigned char *name :property ,char value:content
Return......: tmp
****************************************************************************/
#ifdef SUPPORT_DATA_TYPE_INT8
char *makeInternetExtCmdS8(unsigned char *name, char value)
{
  iot_u16_t i = 0;
  char *tmp = getToInternetBuff();
  tmp[SKY_CMD_ADDRESS_CMDVER] = CMD_VERSION;       // data 1
  tmp[SKY_CMD_ADDRESS_CMD] = SKY_FEEDBACK_A_PARAM; // data 2
  if (NULL != name)
  {
    for (i = 0; name[i] != 0; i++)
    {
      tmp[SKY_CMD_ADDRESS_CMDDATA + i] = name[i]; //  property name
    }
  }
  tmp[SKY_CMD_ADDRESS_CMDDATA + i] = 0; // end with 0
  i++;
  tmp[SKY_CMD_ADDRESS_CMDDATA + i] = SKY_CMD_PARAAM_S8; // 0x80 type:char
  i++;
  tmp[SKY_CMD_ADDRESS_CMDDATA + i] = value;         // value
  tmp[SKY_CMD_ADDRESS_DATALEN] = calcCmdLen(3 + i); // 3 is:( pack len - pack office)(1) + crch(+1) +crcl(+1) = 3
  calcCRCToDataLine(tmp);
  return tmp;
}
#endif

/***************************************************************************
Function....: makeInternetExtCmdS16
Description.: short  type 
Parameters..: unsigned char *name :property ,iot_u16_t value:content
Return......: tmp
****************************************************************************/
#ifdef SUPPORT_DATA_TYPE_INT16
char *makeInternetExtCmdS16(unsigned char *name, iot_u16_t value)
{
  iot_u16_t i = 0;
  char *tmp = getToInternetBuff();
  tmp[SKY_CMD_ADDRESS_CMDVER] = CMD_VERSION;       // data 1
  tmp[SKY_CMD_ADDRESS_CMD] = SKY_FEEDBACK_A_PARAM; // data 2
  if (NULL != name)
  {
    for (i = 0; name[i] != 0; i++)
    {
      tmp[SKY_CMD_ADDRESS_CMDDATA + i] = name[i]; //  property name
    }
  }
  tmp[SKY_CMD_ADDRESS_CMDDATA + i] = 0; // end with 0
  i++;
  tmp[SKY_CMD_ADDRESS_CMDDATA + i] = SKY_CMD_PARAAM_S16; // 0x81 type:short
  i++;
  tmp[SKY_CMD_ADDRESS_CMDDATA + i] = (char)(value & 0xFF); // value high
  i++;
  tmp[SKY_CMD_ADDRESS_CMDDATA + i] = (char)((value >> 8) & 0xff); // value low
  tmp[SKY_CMD_ADDRESS_DATALEN] = calcCmdLen(3 + i);               // 3 is:( pack len - pack office)(1) + crch(+1) +crcl(+1) = 3
  calcCRCToDataLine(tmp);
  return tmp;
}
#endif

/***************************************************************************
Function....: makeInternetExtCmdS32
Description.: int  type 
Parameters..: unsigned char *name :property ,iot_u32_t value:content
Return......: tmp
****************************************************************************/
#ifdef SUPPORT_DATA_TYPE_INT32
char *makeInternetExtCmdS32(unsigned char *name, iot_u32_t value)
{
  iot_u16_t i = 0;
  char *tmp = getToInternetBuff();
  tmp[SKY_CMD_ADDRESS_CMDVER] = CMD_VERSION;       // data 1
  tmp[SKY_CMD_ADDRESS_CMD] = SKY_FEEDBACK_A_PARAM; // data 2
  if (NULL != name)
  {
    for (i = 0; name[i] != 0; i++)
    {
      tmp[SKY_CMD_ADDRESS_CMDDATA + i] = name[i]; //  property name
    }
  }
  tmp[SKY_CMD_ADDRESS_CMDDATA + i] = 0; // end with 0
  i++;
  tmp[SKY_CMD_ADDRESS_CMDDATA + i] = SKY_CMD_PARAAM_S32; // 0x82 type:int
  i++;
  tmp[SKY_CMD_ADDRESS_CMDDATA + i + 3] = (char)((value >> 24) & 0xff);
  tmp[SKY_CMD_ADDRESS_CMDDATA + i + 2] = (char)((value >> 16) & 0xff);
  tmp[SKY_CMD_ADDRESS_CMDDATA + i + 1] = (char)((value >> 8) & 0xff);
  tmp[SKY_CMD_ADDRESS_CMDDATA + i] = (char)(value & 0xff);
  i += 3;
  tmp[SKY_CMD_ADDRESS_DATALEN] = calcCmdLen(3 + i); // 3 is:( pack len - pack office)(1) + crch(+1) +crcl(+1) = 3
  calcCRCToDataLine(tmp);
  return tmp;
}
#endif

/***************************************************************************
Function....: makeInternetExtCmdF32
Description.: float  type 
Parameters..: unsigned char *name :property ,float value:content
Return......: tmp
****************************************************************************/
#ifdef SUPPORT_DATA_TYPE_FLOAT
char *makeInternetExtCmdF32(unsigned char *name, float value)
{
  iot_u16_t i = 0;
  float *floatTmp = &value;
  char *tmp = getToInternetBuff();
  tmp[SKY_CMD_ADDRESS_CMDVER] = CMD_VERSION;       // data 1
  tmp[SKY_CMD_ADDRESS_CMD] = SKY_FEEDBACK_A_PARAM; // data 2
  if (NULL != name)
  {
    for (i = 0; name[i] != 0; i++)
    {
      tmp[SKY_CMD_ADDRESS_CMDDATA + i] = name[i]; //  property name
    }
  }
  tmp[SKY_CMD_ADDRESS_CMDDATA + i] = 0; // end with 0
  i++;
  tmp[SKY_CMD_ADDRESS_CMDDATA + i] = SKY_CMD_PARAAM_F32; // 0x83 type:float
  i++;
#ifdef __HAS_BIG_ENDIAN__
  tmp[SKY_CMD_ADDRESS_CMDDATA + i + 3] = ((char *)floatTmp)[0];
  tmp[SKY_CMD_ADDRESS_CMDDATA + i + 2] = ((char *)floatTmp)[1];
  tmp[SKY_CMD_ADDRESS_CMDDATA + i + 1] = ((char *)floatTmp)[2];
  tmp[SKY_CMD_ADDRESS_CMDDATA + i] = ((char *)floatTmp)[3];
#else
  tmp[SKY_CMD_ADDRESS_CMDDATA + i + 3] = ((char *)floatTmp)[3];
  tmp[SKY_CMD_ADDRESS_CMDDATA + i + 2] = ((char *)floatTmp)[2];
  tmp[SKY_CMD_ADDRESS_CMDDATA + i + 1] = ((char *)floatTmp)[1];
  tmp[SKY_CMD_ADDRESS_CMDDATA + i] = ((char *)floatTmp)[0];
#endif

  i += 3;
  tmp[SKY_CMD_ADDRESS_DATALEN] = calcCmdLen(3 + i); // 3 is:( pack len - pack office)(1) + crch(+1) +crcl(+1) = 3
  calcCRCToDataLine(tmp);
  return tmp;
}
#endif

// unsigned long *getSysUploadMasksP(){
//     static unsigned long masks = 0;
//     return &masks;
// }

// unsigned long *getExtUploadMasksP(){
//     static unsigned long masks = 0;
//     return &masks;
// }

/***************************************************************************
Function....: setUploadMaskBit
Description.: set mask bit 
Parameters..: 
Return......: NONE
****************************************************************************/
void setUploadMaskBit(unsigned long Bit, unsigned long *masks)
{
  *masks |= Bit;
}

/***************************************************************************
Function....: cleanUploadMaskBit
Description.: clean mask bit 
Parameters..: 
Return......: NONE
****************************************************************************/
void cleanUploadMaskBit(unsigned long Bit, unsigned long *masks)
{
  *masks &= ~((unsigned long)Bit);
}

/***************************************************************************
Function....: checkUploadMaskBit
Description.: check the status of mask
Parameters..: 
Return......: NONE
****************************************************************************/
unsigned char checkUploadMaskBit(unsigned long Bit, unsigned long *masks)
{
  return (*masks & Bit) > 0 ? 1 : 0;
}

/***************************************************************************
Function....: checkAndCleanUploadMaskBit
Description.: check the status of mask and clean
Parameters..: 
Return......: rtn
****************************************************************************/
unsigned char checkAndCleanUploadMaskBit(unsigned long Bit, unsigned long *masks)
{
  unsigned char rtn = (*masks & Bit) > 0 ? 1 : 0;
  if (rtn)
  {
    *masks &= ~((unsigned long)Bit);
  }
  return rtn;
}

/***************************************************************************
Function....: parsSkyParamInt
Description.: match property type and data type conversion
Parameters..: char *address : need to change type coversion
Parameters..: char type : char(0x80),short(0x81),int(0x82),
Return......: rtn
****************************************************************************/
iot_u32_t parsSkyParamInt(char *address, char type)
{
  char i, len;
  long tmp = 0, rtn = 0;
  if ((char)SKY_CMD_PARAAM_S32 < type || (char)SKY_CMD_PARAAM_S8 > type) // type exceed limits
  {
    return 0;
  }
  len = 1 << (type - SKY_CMD_PARAAM_S8); // calculate the length of the type
  //    for (i = 0; i < len ; i++){
  //        rtn += (long)address[i] << (8*i);
  //    }

  for (i = 0; i < len; i++)
  {
    tmp = (unsigned long)address[i] & 0xFF;
    rtn += tmp << (8 * i);
  }
  return rtn;
}
/***************************************************************************
Function....: parsSkyParamInt
Description.: change int to char,get every byte
Parameters..: iot_u32_t Data
Return......: rtn
****************************************************************************/
unsigned char *codeSkyParamS32(iot_u32_t Data)
{
  static EXT_DATA_TYPE volatile unsigned char tmp[4];
  tmp[3] = (char)((Data >> 24) & 0xff);
  tmp[2] = (char)((Data >> 16) & 0xff);
  tmp[1] = (char)((Data >> 8) & 0xff);
  tmp[0] = (char)Data & 0xff;
  return (unsigned char *)tmp;
}
/***************************************************************************
Function....: codeSkyParamS16
Description.: change short to char,get every byte
Parameters..: iot_u16_t Data
Return......: rtn
****************************************************************************/
// unsigned char *codeSkyParamS16(iot_u16_t Data)
// {
//   unsigned char *tmp = codeSkyParamS32((iot_u32_t)Data);
//   return tmp;
// }

// char *codeSkyParamStr(char *address){
//     return address;
// }

// char *parsSkyParamStr(char *address){
//     return address;
// }
/***************************************************************************
Function....: codeSkyParamF32
Description.: transformation between big-endian and little 
Parameters..: float *Data_p
Return......: rtn
****************************************************************************/
#ifdef SUPPORT_DATA_TYPE_FLOAT
unsigned char *codeSkyParamF32(float *Data_p)
{
#ifdef __HAS_BIG_ENDIAN__
  unsigned char *tmp = codeSkyParamS32(0);
  tmp[3] = ((char *)Data_p)[0];
  tmp[2] = ((char *)Data_p)[1];
  tmp[1] = ((char *)Data_p)[2];
  tmp[0] = ((char *)Data_p)[3];
  return tmp;
#else
  return (unsigned char *)Data_p;
#endif
}

float parsSkyParamFloat(unsigned char *address)
{
  float rtn = 0;
  unsigned char *pf;
  pf = (unsigned char *)&rtn;

#ifdef __HAS_BIG_ENDIAN__
  pf[0] = address[3];
  pf[1] = address[2];
  pf[2] = address[1];
  pf[3] = address[0];
  return rtn;
#else
  pf[0] = address[0];
  pf[1] = address[1];
  pf[2] = address[2];
  pf[3] = address[3];
#endif
  return rtn;
}
#endif

/***************************************************************************
Function....: GetCRC16
Description.: Using CRC-MODBUS  algorithms
Parameters..: iot_u8_t *buf:array,iot_u16_t length:length of array
Return......: rtn
****************************************************************************/
iot_u16_t GetCRC16(volatile iot_u8_t *buf, iot_u16_t length)
{
  iot_u16_t i;
  iot_u16_t j;
  iot_u16_t c;
  iot_u16_t crc = 0xFFFF;

  for (i = 0; i < length; i++)
  {
    c = *(buf + i) & 0x00FF;
    crc ^= c;
    for (j = 0; j < 8; j++)
    {
      if (crc & 0x0001)
      {
        crc >>= 1;
        crc ^= 0xA001;
      }
      else
        crc >>= 1;
    }
  }
  return crc;
}
