/**
* Copyright(C),Skyworth Group Co.,Ltd  
* Author: dengxuechao@skyworth.com dengxuechao509@qq.com
* Version:  0.1.0
* MIT Licensed
*
* MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
* MMMMM:.........MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM....MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
* MMMN...........MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM ...MMMMMMMMMMMMMMMMMMMMMMMMM . MMMMM
* MMM.... MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM ...MMMMM
* MMM ...MMMMMMMMMM  ..MMMMMMM....:MMMMMMM ..$MMM,........,MMMMMM ...MMMMMMMM ......MMMMMM .........MM
* MMM. .  OMMMMMMMMM . +MMMMMM.....MMMMMM ...MMM .. , ......NMMMM ...MMMMM  ..........NMMM..........MM
* MMMMM ....NMMMMMMM....MMMMM .....MMMMM ...MMMMMMMMMMMMD....MMMM ...MMMM....~MMMMM ...=MMMM,...MMMMMM
* MMMMMM=....,MMMMMMM ..IMMMD .. ...MMMM ..MMMMMMMMMMMMM ....MMMM ...MMM ...MMMMMMMM ...MMMM ...MMMMMM
* MMMMMMMM  ... MMMMM....MMM...MM ..MMM .. MMMMMMM ......... MMMD....MMM ...MMMMMMMM ...MMMM....MMMMMM
* MMMMMMMMMM  .. MMMMM...?M,.. MM....M=...MMMMM ... .?MM8...8MMM~...?MMM....MMMMMMMM ...MMMM....MMMMMM
* MMMMMMMMMMM. ..MMMMM~...M ..MMMM ..M...MMMMM ...MMMMMM:...MMMM ...?MMM....MMMMMMMM ...MMMM ...MMMMMM
* MM :MNMMMM.....MMMMMM .....OMMMM......?MMMMM....MMMMMM....MMMM....?MMMM....MMMMM, ...MMMMM ...8MMMMM
* MM . .........MMMMMMMM,....MMMMM:.... MMMMMM  ......,M....MMMM ...MMMMMM  ......... MMMMMM  ......MM
* MMMI.. . . ZMMMMMMMMMM ...MMMMMMM ...MMMMMMMMN  ....MM....MMMM....MMMMMMMM7. ... MMMMMMMMMM$. .  ,MM
* MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
**/

#ifndef __IOT_CORE_H__
#define __IOT_CORE_H__
#include "iot_config.h"

#ifndef EXT_DATA_TYPE
#define EXT_DATA_TYPE
#endif

// #ifdef __IOT_CONFIG_C51__
// #ifndef __stdint_h
// typedef unsigned char uint8_t;
// typedef unsigned int uint16_t;
// typedef unsigned long uint32_t;
// #endif
// #else
// #ifndef __stdint_h
// typedef unsigned char uint8_t;
// typedef unsigned short int uint16_t; //
// typedef unsigned int uint32_t;
// #endif
// #endif

#ifdef SUPPORT_RECEIVE_LOOP
typedef struct
{
  volatile unsigned char array[RECEIVE_LOOP_SIZE];
  volatile unsigned char headI;
  volatile unsigned char tailI;
  volatile unsigned int arraySize;
} LoopData;
#endif

#define getSysUploadMasksP() (&sysMask)
#define getExtUploadMasksP() (&extMask)

// update mask
extern EXT_DATA_TYPE unsigned long sysMask;
extern EXT_DATA_TYPE unsigned long extMask;
extern EXT_DATA_TYPE char *ver;
extern EXT_DATA_TYPE char *platform;
extern EXT_DATA_TYPE unsigned char *sn;

#ifdef SUPPORT_RECEIVE_LOOP
// extern LoopData *getLoopData(void);
extern void pushByteToLoop(unsigned char Data);
extern unsigned char getLoopDataLen(void);
extern char pullLoopData(iot_u8_t *pullData);
#endif
extern unsigned char checkUploadMaskBit(unsigned long Bit, unsigned long *masks);
extern void cleanUploadMaskBit(unsigned long Bit, unsigned long *masks);
extern void setUploadMaskBit(unsigned long Bit, unsigned long *masks);
extern unsigned char checkAndCleanUploadMaskBit(unsigned long Bit, unsigned long *masks);
extern char *makeSysReply(char cmdType, char paramType, unsigned char *Data, char datalen);
#ifdef SUPPORT_DATA_TYPE_STRING
extern char *makeInternetExtCmdStr(unsigned char *name, char *value);
#endif
#ifdef SUPPORT_DATA_TYPE_INT8
extern char *makeInternetExtCmdS8(unsigned char *name, char value);
#endif
#ifdef SUPPORT_DATA_TYPE_INT16
extern char *makeInternetExtCmdS16(unsigned char *name, iot_u16_t value);
#endif
#ifdef SUPPORT_DATA_TYPE_INT32
extern char *makeInternetExtCmdS32(unsigned char *name, iot_u32_t value);
#endif
#ifdef SUPPORT_DATA_TYPE_FLOAT
extern char *makeInternetExtCmdF32(unsigned char *name, float value);
#endif

#endif
