/**
* Copyright(C),Skyworth Group Co.,Ltd  
* Author: dengxuechao@skyworth.com dengxuechao509@qq.com
* Version:  0.1.0
* MIT Licensed
*
* MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
* MMMMM:.........MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM....MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
* MMMN...........MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM ...MMMMMMMMMMMMMMMMMMMMMMMMM . MMMMM
* MMM.... MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM ...MMMMM
* MMM ...MMMMMMMMMM  ..MMMMMMM....:MMMMMMM ..$MMM,........,MMMMMM ...MMMMMMMM ......MMMMMM .........MM
* MMM. .  OMMMMMMMMM . +MMMMMM.....MMMMMM ...MMM .. , ......NMMMM ...MMMMM  ..........NMMM..........MM
* MMMMM ....NMMMMMMM....MMMMM .....MMMMM ...MMMMMMMMMMMMD....MMMM ...MMMM....~MMMMM ...=MMMM,...MMMMMM
* MMMMMM=....,MMMMMMM ..IMMMD .. ...MMMM ..MMMMMMMMMMMMM ....MMMM ...MMM ...MMMMMMMM ...MMMM ...MMMMMM
* MMMMMMMM  ... MMMMM....MMM...MM ..MMM .. MMMMMMM ......... MMMD....MMM ...MMMMMMMM ...MMMM....MMMMMM
* MMMMMMMMMM  .. MMMMM...?M,.. MM....M=...MMMMM ... .?MM8...8MMM~...?MMM....MMMMMMMM ...MMMM....MMMMMM
* MMMMMMMMMMM. ..MMMMM~...M ..MMMM ..M...MMMMM ...MMMMMM:...MMMM ...?MMM....MMMMMMMM ...MMMM ...MMMMMM
* MM :MNMMMM.....MMMMMM .....OMMMM......?MMMMM....MMMMMM....MMMM....?MMMM....MMMMM, ...MMMMM ...8MMMMM
* MM . .........MMMMMMMM,....MMMMM:.... MMMMMM  ......,M....MMMM ...MMMMMM  ......... MMMMMM  ......MM
* MMMI.. . . ZMMMMMMMMMM ...MMMMMMM ...MMMMMMMMN  ....MM....MMMM....MMMMMMMM7. ... MMMMMMMMMM$. .  ,MM
* MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
**/

#ifndef __IOT_INTERFACE_H__
#define __IOT_INTERFACE_H__
#include "iot_config.h"
// receive

#ifdef LISTENER_MODULE_STATUS
extern void moduleStateChangeHandler(ENUM_MODULE_STATE_SKY state);
#endif
#ifdef SUPPORT_DATA_TYPE_INT8
extern void receiveAPropS8(char *name, iot_s8_t value);
#endif

#ifdef SUPPORT_DATA_TYPE_INT16
extern void receiveAPropS16(char *name, iot_s16_t value);
#endif
#ifdef SUPPORT_DATA_TYPE_INT32
extern void receiveAPropS32(char *name, iot_s32_t value);
#endif
#ifdef SUPPORT_DATA_TYPE_FLOAT
extern void receiveAPropF32(char *name, float value);
#endif
#ifdef SUPPORT_DATA_TYPE_STRING
extern void receiveAPropStr(char *name, char *value_p);
#endif

#ifdef SUPPORT_GET_UTC
extern void moduleTimeHandler(iot_s32_t utc);
#endif
#ifdef SUPPORT_GET_SSID
extern void moduleSSIDHandler(unsigned char *ssid);
#endif
#ifdef SUPPORT_GET_RSSI
extern void moduleRssiHandler(unsigned char rssi);
#endif
#ifdef SUPPORT_GET_IP
extern void moduleIPHandler(unsigned char *ip);
#endif
#ifdef SUPPORT_GET_MAC
extern void moduleMACHandler(unsigned char *mac);
#endif
#ifdef SUPPORT_UPDATE
extern unsigned char setFirmwareSize(iot_s32_t firmwareSize);
extern void changeUpdateRate(void);
extern void updatePack(iot_u32_t packNumber, unsigned char *Pack_p);
#endif
#ifdef SUPPORT_SERIAL_NUMBER
extern void moduleSetSerialNumber(char *sn_p);
#endif

// #ifdef SUPPORT_DELAY_REPLY
extern char *makeExtCmdToModule(void);
// #endif

#endif
