
/**
* Copyright(C),Skyworth Group Co.,Ltd  
* Author: dengxuechao@skyworth.com dengxuechao509@qq.com
* Version:  0.1.0
* MIT Licensed
*
* MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
* MMMMM:.........MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM....MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
* MMMN...........MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM ...MMMMMMMMMMMMMMMMMMMMMMMMM . MMMMM
* MMM.... MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM ...MMMMM
* MMM ...MMMMMMMMMM  ..MMMMMMM....:MMMMMMM ..$MMM,........,MMMMMM ...MMMMMMMM ......MMMMMM .........MM
* MMM. .  OMMMMMMMMM . +MMMMMM.....MMMMMM ...MMM .. , ......NMMMM ...MMMMM  ..........NMMM..........MM
* MMMMM ....NMMMMMMM....MMMMM .....MMMMM ...MMMMMMMMMMMMD....MMMM ...MMMM....~MMMMM ...=MMMM,...MMMMMM
* MMMMMM=....,MMMMMMM ..IMMMD .. ...MMMM ..MMMMMMMMMMMMM ....MMMM ...MMM ...MMMMMMMM ...MMMM ...MMMMMM
* MMMMMMMM  ... MMMMM....MMM...MM ..MMM .. MMMMMMM ......... MMMD....MMM ...MMMMMMMM ...MMMM....MMMMMM
* MMMMMMMMMM  .. MMMMM...?M,.. MM....M=...MMMMM ... .?MM8...8MMM~...?MMM....MMMMMMMM ...MMMM....MMMMMM
* MMMMMMMMMMM. ..MMMMM~...M ..MMMM ..M...MMMMM ...MMMMMM:...MMMM ...?MMM....MMMMMMMM ...MMMM ...MMMMMM
* MM :MNMMMM.....MMMMMM .....OMMMM......?MMMMM....MMMMMM....MMMM....?MMMM....MMMMM, ...MMMMM ...8MMMMM
* MM . .........MMMMMMMM,....MMMMM:.... MMMMMM  ......,M....MMMM ...MMMMMM  ......... MMMMMM  ......MM
* MMMI.. . . ZMMMMMMMMMM ...MMMMMMM ...MMMMMMMMN  ....MM....MMMM....MMMMMMMM7. ... MMMMMMMMMM$. .  ,MM
* MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
**/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "iot_core.h"
#ifdef SUPPORT_RECEIVE_LOOP
// #include "cJSON.h"
// static const char *TAG = "CMD_MANAGER";

/**
    * option.c/c++.misc controls:--c99
    **/
// static LoopData rx_cmd_queue = //{rxArray,0 ,0,UART_RX_BUFFER_SIZE};
//     {
//         .array = {0},
//         .headI = 0,
//         .tailI = 0,
//         .arraySize = BUF_SIZE,
//     };
/**
    * --c90
    **/
static EXT_DATA_TYPE LoopData loopData =
    {
        {0},
        0,
        0,
        RECEIVE_LOOP_SIZE};

// LoopData *getLoopData(void)
// {
//   return &loopData;
// }
/***************************************************************************
Function....: pushByteToLoop
Description.: pull byte into loop
Parameters..: unsigned char Data
Return......: NONE
****************************************************************************/
void pushByteToLoop(unsigned char Data)
{
  loopData.array[loopData.tailI] = Data;
  if ((loopData.tailI + 1) >= loopData.arraySize) // exceed array size
  {
    loopData.tailI = 0;
  }
  else
  {
    loopData.tailI = loopData.tailI + 1;
  }
  if (loopData.headI == loopData.tailI)
  { // overflow
    if ((loopData.headI + 1) >= loopData.arraySize)
    {
      loopData.headI = 0;
    }
    else
    {
      loopData.headI++;
    }
  }
}
/***************************************************************************
Function....: getLoopDataLen
Description.: get the length of loop data
Parameters..: NONE
Return......: rtn
****************************************************************************/
unsigned char getLoopDataLen()
{
  unsigned char rtn = 0;

  if (loopData.headI != loopData.tailI)
  {
    if (loopData.headI < loopData.tailI)
    {
      rtn = loopData.tailI - loopData.headI;
    }
    else
    {
      rtn = loopData.arraySize - loopData.headI + loopData.tailI;
    }
  }
  return rtn;
}

/***************************************************************************
Function....: pullLoopData
Description.: pull data from loop
Parameters..: NONE
Return......: rtn
****************************************************************************/
char pullLoopData(iot_u8_t *pullData)
{
  char rtn = 0;

  if (loopData.headI != loopData.tailI)
  {
    *pullData = loopData.array[loopData.headI];
    rtn = 0;
    if ((loopData.headI + 1) >= loopData.arraySize)
    {
      loopData.headI = 0;
    }
    else
    {
      loopData.headI++;
    }
  }
  return rtn;
}
#endif
