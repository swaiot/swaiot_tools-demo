/**
* Copyright(C),Skyworth Group Co.,Ltd  
* Author: dengxuechao@skyworth.com dengxuechao509@qq.com
* Review and doc: xumeilin@skyworth.com
* Version:  0.2.1
* MIT Licensed
*
* MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
* MMMMM:.........MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM....MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
* MMMN...........MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM ...MMMMMMMMMMMMMMMMMMMMMMMMM . MMMMM
* MMM.... MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM ...MMMMM
* MMM ...MMMMMMMMMM  ..MMMMMMM....:MMMMMMM ..$MMM,........,MMMMMM ...MMMMMMMM ......MMMMMM .........MM
* MMM. .  OMMMMMMMMM . +MMMMMM.....MMMMMM ...MMM .. , ......NMMMM ...MMMMM  ..........NMMM..........MM
* MMMMM ....NMMMMMMM....MMMMM .....MMMMM ...MMMMMMMMMMMMD....MMMM ...MMMM....~MMMMM ...=MMMM,...MMMMMM
* MMMMMM=....,MMMMMMM ..IMMMD .. ...MMMM ..MMMMMMMMMMMMM ....MMMM ...MMM ...MMMMMMMM ...MMMM ...MMMMMM
* MMMMMMMM  ... MMMMM....MMM...MM ..MMM .. MMMMMMM ......... MMMD....MMM ...MMMMMMMM ...MMMM....MMMMMM
* MMMMMMMMMM  .. MMMMM...?M,.. MM....M=...MMMMM ... .?MM8...8MMM~...?MMM....MMMMMMMM ...MMMM....MMMMMM
* MMMMMMMMMMM. ..MMMMM~...M ..MMMM ..M...MMMMM ...MMMMMM:...MMMM ...?MMM....MMMMMMMM ...MMMM ...MMMMMM
* MM :MNMMMM.....MMMMMM .....OMMMM......?MMMMM....MMMMMM....MMMM....?MMMM....MMMMM, ...MMMMM ...8MMMMM
* MM . .........MMMMMMMM,....MMMMM:.... MMMMMM  ......,M....MMMM ...MMMMMM  ......... MMMMMM  ......MM
* MMMI.. . . ZMMMMMMMMMM ...MMMMMMM ...MMMMMMMMN  ....MM....MMMM....MMMMMMMM7. ... MMMMMMMMMM$. .  ,MM
* MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
**/

#include <stdio.h>
#include "iot_core.h"
#include "iot_interface.h"
#include "iot_user_config.h"

#ifdef CMD_MASK_PROD_STATUS 
  EXT_DATA_TYPE unsigned char cmdMaskPropStatus;
#endif 


#ifdef CMD_MASK_PROD_STATUS 
  void sendcmdPropStatus(unsigned char value){
    #ifdef SUPPORT_DELAY_REPLY 
      setUploadMaskBit(CMD_MASK_PROD_STATUS, getExtUploadMasksP()); 
    #else 
      char *sendCmdLine = makeInternetExtCmdU8((unsigned char *)PROD_STATUS_NAME,value); 
      SEND_TO_NET_CMD(sendCmdLine, sendCmdLine[SKY_CMD_ADDRESS_DATALEN]);
    #endif 
      cmdMaskPropStatus = value; // Cache properties
  } 
#endif 

/** delay reply function **/ 

  char *makeExtCmdToModule(){
    if(checkAndCleanUploadMaskBit(CMD_MASK_PROD_STATUS, getExtUploadMasksP()) == 1){ 
      return makeInternetExtCmdU8((unsigned char *)PROD_STATUS_NAME, cmdMaskPropStatus); 
    }
    return 0;
  }
    
// common 
#ifdef LISTENER_MODULE_STATUS
void sendCmdGetModuleState(){
    #ifdef SUPPORT_DELAY_REPLY
        setUploadMaskBit(CMD_UPLOAD_MASK_REQUEST_NETSTATE, getSysUploadMasksP());
    #else
        char *sendCmdLine = makeSysReply(
            SKY_DEMAND_STA_STATE, 
            SKY_CMD_PARAAM_NULL, 
            NULL, 0);
        SEND_TO_NET_CMD(sendCmdLine, sendCmdLine[SKY_CMD_ADDRESS_DATALEN]);
    #endif
}
#endif
void sendCmdSetModuleConnect(){
    #ifdef SUPPORT_DELAY_REPLY
        setUploadMaskBit(CMD_UPLOAD_MASK_REQUEST_CONNECT, getSysUploadMasksP());
    #else
        char *sendCmdLine = makeSysReply(
            SKY_ORDER_CONFIG_WIFI, 
            SKY_CMD_PARAAM_NULL, 
            NULL, 0);
        SEND_TO_NET_CMD(sendCmdLine, sendCmdLine[SKY_CMD_ADDRESS_DATALEN]);
    #endif
}

void sendCmdSetModuleFacTest(){
    #ifdef SUPPORT_DELAY_REPLY
        setUploadMaskBit(CMD_UPLOAD_MASK_REQUEST_FAC, getSysUploadMasksP());
    #else
        char *sendCmdLine = makeSysReply(
            SKY_ORDER_FACTORY_MODE, 
            SKY_CMD_PARAAM_NULL, 
            NULL, 0);
        SEND_TO_NET_CMD(sendCmdLine, sendCmdLine[SKY_CMD_ADDRESS_DATALEN]);
    #endif
}

void sendCmdSetModuleUnbind(){
    #ifdef SUPPORT_DELAY_REPLY
        setUploadMaskBit(CMD_UPLOAD_MASK_REQUEST_UNBIND, getSysUploadMasksP());
    #else
        char *sendCmdLine = makeSysReply(
            SKY_ORDER_FORCE_UNBIND, 
            SKY_CMD_PARAAM_NULL, 
            NULL, 0);
        SEND_TO_NET_CMD(sendCmdLine, sendCmdLine[SKY_CMD_ADDRESS_DATALEN]);
    #endif
}

#ifdef SUPPORT_GET_UTC
void sendCmdGetUtc(){
    #ifdef SUPPORT_DELAY_REPLY
        setUploadMaskBit(CMD_UPLOAD_MASK_REQUEST_TIME, getSysUploadMasksP());
    #else
        char *sendCmdLine = makeSysReply(
            SKY_DEMAND_CURRENT_TIME, 
            SKY_CMD_PARAAM_NULL, 
            NULL, 
            0);
        SEND_TO_NET_CMD(sendCmdLine, sendCmdLine[SKY_CMD_ADDRESS_DATALEN]);
    #endif
    
}
#endif

#ifdef SUPPORT_GET_IP
void sendCmdGetIp(){
    #ifdef SUPPORT_DELAY_REPLY
        setUploadMaskBit(CMD_UPLOAD_MASK_REQUEST_IP, getSysUploadMasksP());
    #else
        char *sendCmdLine = makeSysReply(SKY_ORDER_CURRENT_IP, SKY_CMD_PARAAM_NULL, NULL, 0);
        SEND_TO_NET_CMD(sendCmdLine, sendCmdLine[SKY_CMD_ADDRESS_DATALEN]);
    #endif
    
}
#endif

#ifdef SUPPORT_GET_SSID
void sendCmdGetSsid(){
    #ifdef SUPPORT_DELAY_REPLY
        setUploadMaskBit(CMD_UPLOAD_MASK_REQUEST_SSID, getSysUploadMasksP());
    #else
        char *sendCmdLine = makeSysReply(SKY_ORDER_CURRENT_SSID, SKY_CMD_PARAAM_NULL, NULL, 0);
        SEND_TO_NET_CMD(sendCmdLine, sendCmdLine[SKY_CMD_ADDRESS_DATALEN]);
    #endif
    
}
#endif

#ifdef SUPPORT_GET_MAC
void sendCmdGetMac(){
    #ifdef SUPPORT_DELAY_REPLY
        setUploadMaskBit(CMD_UPLOAD_MASK_REQUEST_MAC, getSysUploadMasksP());
    #else
        char *sendCmdLine = makeSysReply(SKY_ORDER_STA_MAC, SKY_CMD_PARAAM_NULL, NULL, 0);
        SEND_TO_NET_CMD(sendCmdLine, sendCmdLine[SKY_CMD_ADDRESS_DATALEN]);
    #endif
}
#endif

#ifdef SUPPORT_GET_RSSI
void sendCmdGetRssi(){
    #ifdef SUPPORT_DELAY_REPLY
        setUploadMaskBit(CMD_UPLOAD_MASK_REQUEST_RSSI, getSysUploadMasksP());
    #else
        char *sendCmdLine = makeSysReply(SKY_ORDER_SIGNAL_RSSI, SKY_CMD_PARAAM_NULL, NULL, 0);
        SEND_TO_NET_CMD(sendCmdLine, sendCmdLine[SKY_CMD_ADDRESS_DATALEN]);
    #endif
}
#endif

